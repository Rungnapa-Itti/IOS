//
//  Room.swift
//  Readyy
//
//  Created by Milk on 9/10/2562 BE.
//  Copyright © 2562 Ratsuda Suwan. All rights reserved.
//

import Foundation
class Room{
    private var room:Dictionary<String, Any>
    
    init() {
        self.room = Dictionary<String,Gamer>()
    }
    
    
    
    
    

}
